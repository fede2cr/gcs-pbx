if(!dojo._hasResource["tests.NodeList-manipulate"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["tests.NodeList-manipulate"] = true;
dojo.provide("tests.NodeList-manipulate");
if(dojo.isBrowser){
	doh.registerUrl("tests.NodeList-manipulate", dojo.moduleUrl("tests", "NodeList-manipulate.html"));
}

}
