if(!dojo._hasResource["tests.behavior"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["tests.behavior"] = true;
dojo.provide("tests.behavior");
if(dojo.isBrowser){
	doh.registerUrl("tests.behavior", dojo.moduleUrl("tests", "behavior.html"));
}

}
