if(!dojo._hasResource["tests.NodeList-traverse"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["tests.NodeList-traverse"] = true;
dojo.provide("tests.NodeList-traverse");
if(dojo.isBrowser){
	doh.registerUrl("tests.NodeList-traverse", dojo.moduleUrl("tests", "NodeList-traverse.html"));
}

}
