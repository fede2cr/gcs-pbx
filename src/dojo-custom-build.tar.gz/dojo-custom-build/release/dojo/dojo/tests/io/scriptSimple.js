myTasks = new Array();
myTasks[0] = 'Take out trash.';
myTasks[1] = 'Do dishes.';
myTasks[2] = 'Brush teeth.';

