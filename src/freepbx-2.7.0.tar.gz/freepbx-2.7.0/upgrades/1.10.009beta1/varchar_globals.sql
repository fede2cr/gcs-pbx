ALTER TABLE  globals CHANGE  variable  variable VARCHAR( 20 ) NOT NULL ,
CHANGE  value  value VARCHAR( 50 ) NOT NULL;
