<?php
// As part of the new UI, make sure that the old 'amp.bmp' is changed to 'freepbx.png'
if ($amp_conf['AMPADMINLOGO'] == "amp.bmp") {
	$amp_conf['AMPADMINLOGO'] == "freepbx.png";
}
?>
