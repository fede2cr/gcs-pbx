ALTER TABLE  `extensions` CHANGE  `args`  `args` VARCHAR( 255 ) DEFAULT NULL;
