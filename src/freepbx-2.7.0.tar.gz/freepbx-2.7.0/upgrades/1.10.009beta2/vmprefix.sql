DELETE FROM `globals` WHERE variable = 'VM_PREFIX';

INSERT INTO `globals` VALUES ('VM_PREFIX', '*');
