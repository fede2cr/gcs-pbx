<?php

/**
 * @file
 * main
 */

include_once("includes/bootstrap.php");
ariPageHeader();
include_once("includes/common.php");

handler();

ariPageFooter();


?>



