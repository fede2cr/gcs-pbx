<?php

$template['content'] = 
	"<h2>"._("Unauthorized")."</h2>".
	"<p>"._("You are not authorized to access this page.")."</p>";
showview('freepbx', $template);

?>
